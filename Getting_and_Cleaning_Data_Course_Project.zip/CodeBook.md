
# Code Book

## Dataset Overview
The tidy dataset contains the average of mean and standard deviation measurements from the UCI HAR Dataset for each Subject and Activity.

## Variables
- `Subject` : Identifier for each participant.
- `Activity` : Activity performed (e.g., WALKING, SITTING, etc.)
- `tBodyAcc-mean()-X_mean` : Average of mean X-axis body acceleration.
- `tBodyAcc-mean()-Y_mean` : Average of mean Y-axis body acceleration.
- `tBodyAcc-std()-X_mean` : Average of standard deviation X-axis body acceleration.
- ... (other mean/std variables similarly named)

## Cleaning Steps
1. Merged training and test datasets.
2. Extracted only columns with mean() or std() measurements.
3. Replaced activity codes with descriptive names.
4. Labeled dataset with descriptive variable names.
5. Created tidy dataset with average of each variable for each Subject and Activity.
