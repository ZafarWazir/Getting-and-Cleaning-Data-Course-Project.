
# Getting and Cleaning Data Course Project

## Overview
This repository contains the code and data for the Coursera "Getting and Cleaning Data" course project.

## Files
- `run_analysis.R` : Main script that reads raw Samsung data, cleans it, and produces a tidy dataset.
- `tidy_data.txt` : The resulting tidy dataset.
- `CodeBook.md` : Describes all variables, transformations, and cleaning steps.
- `UCI HAR Dataset/` : Original dataset folder (must be in working directory).

## How to Run
1. Clone this repository.
2. Ensure the `UCI HAR Dataset/` folder is in your working directory.
3. Open R or RStudio and run:
```r
source("run_analysis.R")
```
4. The script will generate `tidy_data.txt`.
